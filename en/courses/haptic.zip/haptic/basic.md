---
title: Basic usage
linktitle: Basic usage
toc: true
type: book
date: "2019-05-05T00:00:00+01:00"
draft: false
menu:
  haptic:
    name: Usage
    weight: 2

# Prev/next pager order (if `docs_section_pager` enabled in `params.toml`)
weight: 1
---

As long as your device support the Vibration API, usage is very simple.

The only functions to use is :
```javascript
navigator.vibrate();
```

If you want to make a simple vibration:

```javascript
// Vibrate for 300ms
navigator.vibrate([300]);
// or
navigator.vibrate(300);
```

<script>function example1() {
// Vibrate for 300ms
 navigator.vibrate([300]);
}
</script>

<button onclick="example1()">Try it !</button>

For more complex pattern you can pass a pattern of vibrations followed by pauses:

```javascript
// 'SOS' in morse code
navigator.vibrate([50,50,50,50,50,150,150,50,150,50,150,150,50,50,50,50,50]]); 
```
<script>function example2() {
 navigator.vibrate([50,50,50,50,50,150,150,50,150,50,150,150,50,50,50,50,50]);
}
</script>

<button onclick="example2()">Try it !</button>

Sometimes smartphone actuator cannot play fast changes, so here is a slower version:

```javascript
// a slower 'SOS' in morse code
navigator.vibrate([100,100,100,100,100,300,300,100,300,100,300,300,100,100,100,100,100]); 
```
<script>function example2b() {
 navigator.vibrate([100,100,100,100,100,300,300,100,300,100,300,300,100,100,100,100,100]);
}
</script>

<button onclick="example2b()">Try it !</button>


To stop a vibration, just call the function with the value 0:

```javascript
navigator.vibrate(0)
```
<script>function example3s() {
 navigator.vibrate(3000);
}
</script>
<script>function example3() {
 navigator.vibrate(0);
}
</script>
<button onclick="example3s()">Start it !</button>
<button onclick="example3()">Stop it !</button>