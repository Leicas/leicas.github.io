---
# Course title, summary, and position.
linktitle: How to create Haptic effect in HTML5
summary: Learn how to use HTML5 vibration API to create haptic feedbacks.
weight: 1

# Page metadata.
title: Overview
date: "2019-10-24T00:00:00Z"
draft: false  # Is this a draft? true/false
toc: true  # Show table of contents? true/false
type: book  # Do not modify.

# Add menu entry to sidebar.
# - name: Declare this menu item as a parent with ID `name`.
# - weight: Position of link in menu.
menu:
  haptic:
    name: Overview
    weight: 1
---

{{% callout warning %}}
Sadly, this is not (yet?) [supported on iOS](https://caniuse.com/#feat=vibration). 
{{% /callout %}}

## Purpose

This feature can be used for adding vibration feedback to webpages interaction:

A quick example, taken from [here](https://googlechrome.github.io/samples/vibration/) can be seen on this page, to try out the vibration API on your device.

<script>
function startPattern() {
// Values at even indices (0, 2, 4, ...) specify vibrations, while the odd
// indices specify pauses.
// Vibrate for 500ms 6 times, pausing for 250ms in between each one.
navigator.vibrate([500, 250, 500, 250, 500, 250, 500, 250, 500, 250, 500]);
}
</script>
    
<div><button onclick="startPattern()">Play pattern</button></div>