---
title: Activity
linktitle: Activity
toc: true
type: book
date: "2019-10-30T00:00:00+01:00"
draft: false
menu:
  haptic:
    name: Activity
    weight: 10

# Prev/next pager order (if `docs_section_pager` enabled in `params.toml`)
weight: 2
---
Try to create vibrations patterns matching different types of content.

<script>function warning() {
 navigator.vibrate(1);
}
</script>
<button onclick="warning()">Warning !</button>
<script>function win() {
 navigator.vibrate(1);
}
</script>
<button onclick="win()">You won !</button>
<script>function loose() {
 navigator.vibrate(1);
}
</script>
<button onclick="loose()">You lost !</button>
<script>function hurry() {
 navigator.vibrate(1);
}
</script>
<button onclick="hurry()">Hurry !</button>

You can start with the following code:
```html
<html>
<head>
<title>Vibrations pattern example</title>
</head>
<body>
<script>function warning() {
 navigator.vibrate(1);
}
</script>
<button onclick="warning()">Warning !</button>
<script>function win() {
 navigator.vibrate(1);
}
</script>
<button onclick="win()">You won !</button>
<script>function loose() {
 navigator.vibrate(1);
}
</script>
<button onclick="loose()">You lost !</button>
<script>function hurry() {
 navigator.vibrate(1);
}
</script>
<button onclick="hurry()">Hurry !</button>
</body>
</html>

```